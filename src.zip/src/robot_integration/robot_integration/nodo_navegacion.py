import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from robot_integration.pid_controller import PIDController, NavegadorFSM

class NodoNavegacionSeguro(Node):
    def __init__(self):
        super().__init__('nodo_navegacion')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pid = PIDController(Kp=0.8, Ki=0.0, Kd=0.1)
        self.robot = NavegadorFSM(self.pid)
        self.timer = self.create_timer(0.1, self.ciclo_navegacion)
        self.get_logger().info('¡CÓDIGO NUEVO FORZADO! Acelerando el vehículo...')

    def ciclo_navegacion(self):
        motor_izq, motor_der = self.robot.actualizar_estado(0.0, False)
        cmd = Twist()
        cmd.linear.x = ((motor_izq + motor_der) / 510.0) * 0.5 
        cmd.angular.z = (motor_der - motor_izq) / 150.0 
        self.publisher_.publish(cmd)

def main(args=None):
    rclpy.init()
    nodo = NodoNavegacionSeguro()
    rclpy.spin(nodo)
    nodo.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
